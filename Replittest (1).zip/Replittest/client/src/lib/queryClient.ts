import { QueryClient, QueryFunction } from "@tanstack/react-query";
import { getMockData } from "./dummyData";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  // Return mock response for frontend-only operation
  const mockData = await getMockData(url);
  return new Response(JSON.stringify(mockData), {
    status: 200,
    headers: { "Content-Type": "application/json" }
  });
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    // Parse query parameters from the queryKey if they exist
    const url = queryKey[0] as string;
    const queryParams = queryKey[1] as any;
    
    // Return mock data instead of making real API calls
    return await getMockData(url, queryParams);
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
