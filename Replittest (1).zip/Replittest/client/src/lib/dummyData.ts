// Dummy data for frontend-only operation
// This file contains mock data to replace all backend API responses

import { DashboardData } from '@/types';

// Mock dashboard data
export const mockDashboardData: DashboardData = {
  openPayables: {
    total: 245800,
    count: 8
  },
  openReceivables: {
    total: 485240,
    count: 15
  },
  recentTransactions: [
    {
      id: 1,
      transactionType: 'sales_invoice',
      transactionNumber: 'INV-2024-001',
      transactionDate: new Date('2024-03-15'),
      partyId: 1,
      amount: "125000",
      status: 'paid'
    },
    {
      id: 2,
      transactionType: 'purchase_bill',
      transactionNumber: 'BILL-2024-003',
      transactionDate: new Date('2024-03-14'),
      partyId: 2,
      amount: "75000",
      status: 'pending'
    },
    {
      id: 3,
      transactionType: 'receipt',
      transactionNumber: 'REC-2024-012',
      transactionDate: new Date('2024-03-13'),
      partyId: 1,
      amount: "125000",
      status: 'completed'
    },
    {
      id: 4,
      transactionType: 'payment',
      transactionNumber: 'PAY-2024-008',
      transactionDate: new Date('2024-03-12'),
      partyId: 2,
      amount: "50000",
      status: 'completed'
    },
    {
      id: 5,
      transactionType: 'sales_invoice',
      transactionNumber: 'INV-2024-002',
      transactionDate: new Date('2024-03-11'),
      partyId: 3,
      amount: "95000",
      status: 'using_bnpl'
    }
  ],
  receivablesAgeing: {
    current: 148750,
    days1to30: 95240,
    days31to60: 124500,
    days60plus: 116750
  },
  payablesAgeing: {
    current: 48200,
    days1to30: 65300,
    days31to60: 82000,
    days60plus: 50300
  },
  purchaseBnplLimits: [
    {
      id: 1,
      partyId: 2,
      limitType: "purchase",
      totalLimit: "200000",
      usedLimit: "85000",
      expiryDate: new Date('2024-12-31'),
      userId: 1,
      createdAt: new Date('2024-01-01')
    }
  ],
  salesBnplLimits: [
    {
      id: 2,
      partyId: 1,
      limitType: "sales",
      totalLimit: "300000",
      usedLimit: "95000",
      expiryDate: new Date('2024-12-31'),
      userId: 1,
      createdAt: new Date('2024-01-01')
    }
  ],
  recentSyncLog: {
    id: 1,
    syncType: 'pull',
    syncStatus: 'success',
    transactionCount: 156,
    details: 'Successfully synced transactions from Tally',
    userId: 1,
    syncedAt: new Date('2024-03-15T10:30:00Z')
  },
  pendingSyncs: {
    invoices: 3,
    payments: 1,
    receipts: 2
  }
};

// Mock parties (customers and vendors)
export const mockParties = [
  {
    id: 1,
    name: "GlobalTech Solutions",
    type: "customer",
    contactPerson: "Raj Kumar",
    email: "raj@globaltech.com",
    phone: "+91 9876543210",
    address: "Mumbai, Maharashtra",
    gstNumber: "27ABCDE1234F1Z5",
    balance: 125000,
    creditLimit: 500000
  },
  {
    id: 2,
    name: "Bharath Electronics Ltd",
    type: "vendor",
    contactPerson: "Suresh Reddy",
    email: "suresh@bharathelectronics.com",
    phone: "+91 9876543211",
    address: "Hyderabad, Telangana",
    gstNumber: "36FGHIJ5678K2L9",
    balance: -75000,
    creditLimit: 300000
  },
  {
    id: 3,
    name: "Sundar Innovations",
    type: "customer",
    contactPerson: "Priya Sharma",
    email: "priya@sundarinnovations.com",
    phone: "+91 9876543212",
    address: "Bangalore, Karnataka",
    gstNumber: "29MNOPQ9012R3S4",
    balance: 95000,
    creditLimit: 400000
  },
  {
    id: 4,
    name: "Ashok Suppliers",
    type: "vendor",
    contactPerson: "Ashok Gupta",
    email: "ashok@ashoksuppliers.com",
    phone: "+91 9876543213",
    address: "Delhi, NCR",
    gstNumber: "07TUVWX3456Y7Z8",
    balance: -45000,
    creditLimit: 200000
  },
  {
    id: 5,
    name: "Patel Enterprises",
    type: "customer",
    contactPerson: "Kiran Patel",
    email: "kiran@patelenterprises.com",
    phone: "+91 9876543214",
    address: "Ahmedabad, Gujarat",
    gstNumber: "24ABCDE7890F1G2",
    balance: 65000,
    creditLimit: 350000
  }
];

// Mock items/products
export const mockItems = [
  {
    id: 1,
    name: "Laptop Computer",
    sku: "TECH-LAP-001",
    category: "Electronics",
    unit: "Piece",
    salePrice: 65000,
    purchasePrice: 55000,
    stockQuantity: 25,
    reorderLevel: 5,
    stockGroup: "Computers",
    hsnCode: "8471"
  },
  {
    id: 2,
    name: "Office Chair",
    sku: "FURN-CHR-002",
    category: "Furniture",
    unit: "Piece",
    salePrice: 12000,
    purchasePrice: 8000,
    stockQuantity: 45,
    reorderLevel: 10,
    stockGroup: "Office Furniture",
    hsnCode: "9401"
  },
  {
    id: 3,
    name: "Printer Paper A4",
    sku: "STAT-PAP-003",
    category: "Stationery",
    unit: "Ream",
    salePrice: 350,
    purchasePrice: 280,
    stockQuantity: 200,
    reorderLevel: 50,
    stockGroup: "Stationery",
    hsnCode: "4802"
  },
  {
    id: 4,
    name: "LED Monitor",
    sku: "TECH-MON-004",
    category: "Electronics",
    unit: "Piece",
    salePrice: 18000,
    purchasePrice: 14000,
    stockQuantity: 15,
    reorderLevel: 3,
    stockGroup: "Computers",
    hsnCode: "8528"
  },
  {
    id: 5,
    name: "Wireless Mouse",
    sku: "TECH-MOU-005",
    category: "Electronics",
    unit: "Piece",
    salePrice: 1200,
    purchasePrice: 800,
    stockQuantity: 100,
    reorderLevel: 20,
    stockGroup: "Computer Accessories",
    hsnCode: "8471"
  }
];

// Mock transactions
export const mockTransactions = [
  {
    id: 1,
    transactionType: 'sales_invoice',
    transactionNumber: 'INV-2024-001',
    transactionDate: '2024-03-15',
    partyId: 1,
    amount: 125000,
    status: 'paid',
    dueDate: '2024-04-14',
    items: [
      { itemId: 1, quantity: 2, rate: 65000, amount: 130000 },
      { itemId: 5, quantity: 5, rate: 1200, amount: 6000 }
    ]
  },
  {
    id: 2,
    transactionType: 'purchase_bill',
    transactionNumber: 'BILL-2024-003',
    transactionDate: '2024-03-14',
    partyId: 2,
    amount: 75000,
    status: 'pending',
    dueDate: '2024-04-13',
    items: [
      { itemId: 2, quantity: 5, rate: 8000, amount: 40000 },
      { itemId: 3, quantity: 100, rate: 280, amount: 28000 }
    ]
  },
  {
    id: 3,
    transactionType: 'receipt',
    transactionNumber: 'REC-2024-012',
    transactionDate: '2024-03-13',
    partyId: 1,
    amount: 125000,
    status: 'completed'
  },
  {
    id: 4,
    transactionType: 'payment',
    transactionNumber: 'PAY-2024-008',
    transactionDate: '2024-03-12',
    partyId: 2,
    amount: 50000,
    status: 'completed'
  },
  {
    id: 5,
    transactionType: 'sales_invoice',
    transactionNumber: 'INV-2024-002',
    transactionDate: '2024-03-11',
    partyId: 3,
    amount: 95000,
    status: 'using_bnpl',
    dueDate: '2024-04-10',
    items: [
      { itemId: 4, quantity: 5, rate: 18000, amount: 90000 },
      { itemId: 3, quantity: 20, rate: 350, amount: 7000 }
    ]
  }
];

// Mock inventory data
export const mockInventorySummary = {
  totalItems: 5,
  totalValue: 1250000,
  lowStockItems: 2,
  outOfStockItems: 0,
  recentlyAdded: 3
};

// Mock stock groups
export const mockStockGroups = [
  { id: 1, name: "Computers", parentGroup: null, itemCount: 3 },
  { id: 2, name: "Office Furniture", parentGroup: null, itemCount: 1 },
  { id: 3, name: "Stationery", parentGroup: null, itemCount: 1 },
  { id: 4, name: "Computer Accessories", parentGroup: 1, itemCount: 1 }
];

// Mock godowns
export const mockGodowns = [
  { id: 1, name: "Main Warehouse", location: "Mumbai", capacity: 1000 },
  { id: 2, name: "Delhi Branch", location: "New Delhi", capacity: 500 },
  { id: 3, name: "Bangalore Store", location: "Bangalore", capacity: 300 }
];

// Mock units
export const mockUnits = [
  { id: 1, name: "Piece", symbol: "Pcs", type: "quantity" },
  { id: 2, name: "Kilogram", symbol: "Kg", type: "weight" },
  { id: 3, name: "Meter", symbol: "M", type: "length" },
  { id: 4, name: "Ream", symbol: "Rm", type: "quantity" }
];

// Mock BNPL limits
export const mockBnplLimits = [
  {
    id: 1,
    partyId: 1,
    creditLimit: 200000,
    usedLimit: 95000,
    availableLimit: 105000,
    status: 'active'
  },
  {
    id: 2,
    partyId: 3,
    creditLimit: 150000,
    usedLimit: 90000,
    availableLimit: 60000,
    status: 'active'
  }
];

// Mock Tally sync logs
export const mockTallySyncLogs = [
  {
    id: 1,
    syncDate: '2024-03-15T10:30:00Z',
    syncType: 'pull',
    status: 'success',
    recordsSynced: 156,
    errorCount: 0,
    duration: 45
  },
  {
    id: 2,
    syncDate: '2024-03-14T09:15:00Z',
    syncType: 'push',
    status: 'success',
    recordsSynced: 23,
    errorCount: 0,
    duration: 12
  },
  {
    id: 3,
    syncDate: '2024-03-13T16:45:00Z',
    syncType: 'pull',
    status: 'partial_success',
    recordsSynced: 89,
    errorCount: 3,
    duration: 67
  }
];

// Mock marketplace data
export const mockMarketplaceItems = [
  {
    id: 1,
    name: "Premium Office Desk",
    vendor: "Delhi Furniture Co.",
    price: 25000,
    rating: 4.5,
    location: "Delhi",
    category: "Furniture"
  },
  {
    id: 2,
    name: "Wireless Keyboard Set",
    vendor: "Tech Accessories Ltd",
    price: 2500,
    rating: 4.2,
    location: "Bangalore",
    category: "Electronics"
  }
];

export const mockFeaturedProducts = [
  {
    id: 1,
    name: "Business Laptop Pro",
    vendor: "Computer Solutions",
    price: 85000,
    originalPrice: 95000,
    discount: 10,
    rating: 4.8,
    category: "Electronics"
  },
  {
    id: 2,
    name: "Ergonomic Office Chair",
    vendor: "Comfort Seating",
    price: 15000,
    originalPrice: 18000,
    discount: 17,
    rating: 4.6,
    category: "Furniture"
  }
];

// Function to simulate API response delay
export const simulateDelay = (ms: number = 500) => 
  new Promise(resolve => setTimeout(resolve, ms));

// Function to get mock data based on URL pattern
export const getMockData = async (url: string, queryParams?: any): Promise<any> => {
  await simulateDelay(300); // Simulate network delay

  // Dashboard
  if (url.includes('/api/dashboard')) {
    return mockDashboardData;
  }

  // Parties
  if (url.includes('/api/parties')) {
    if (queryParams?.type === 'vendor') {
      return mockParties.filter(party => party.type === 'vendor');
    }
    if (queryParams?.type === 'customer') {
      return mockParties.filter(party => party.type === 'customer');
    }
    return mockParties;
  }

  // Items
  if (url.includes('/api/items') || url.includes('/api/inventory/items')) {
    return mockItems;
  }

  // Transactions
  if (url.includes('/api/transactions')) {
    if (queryParams?.type) {
      return mockTransactions.filter(t => t.transactionType === queryParams.type);
    }
    return mockTransactions;
  }

  // Inventory
  if (url.includes('/api/inventory/summary')) {
    return mockInventorySummary;
  }

  if (url.includes('/api/inventory/stock-groups')) {
    return mockStockGroups;
  }

  if (url.includes('/api/inventory/godowns')) {
    return mockGodowns;
  }

  if (url.includes('/api/inventory/units')) {
    return mockUnits;
  }

  // BNPL
  if (url.includes('/api/bnpl-limits')) {
    return mockBnplLimits;
  }

  // Tally sync
  if (url.includes('/api/tally-sync/logs')) {
    return mockTallySyncLogs;
  }

  if (url.includes('/api/tally-sync/latest')) {
    return mockTallySyncLogs[0];
  }

  // Marketplace
  if (url.includes('/api/marketplace/items')) {
    return mockMarketplaceItems;
  }

  if (url.includes('/api/marketplace/featured')) {
    return mockFeaturedProducts;
  }

  // Ageing analysis
  if (url.includes('/api/ageing/receivables/summary')) {
    return { total: 485240, count: 15 };
  }

  if (url.includes('/api/ageing/payables/summary')) {
    return { total: 245800, count: 8 };
  }

  // Finance specific endpoints
  if (url.includes('/api/finance/receivables/customers')) {
    return mockParties.filter(party => party.type === 'customer');
  }

  if (url.includes('/api/finance/payables/vendors')) {
    return mockParties.filter(party => party.type === 'vendor');
  }

  // Default empty response
  return [];
};